import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class ShopkeeperPro extends JFrame implements ActionListener {

    JTextArea output;
    JButton btnBuy, btnSell, btnKhata, btnShowSales, btnViewStock, btnLogout;

    HashMap<String, Integer> inventory = new HashMap<>();
    ArrayList<String> salesRecords = new ArrayList<>();
    ArrayList<String> khataBook = new ArrayList<>();

    double totalSales = 0;
    boolean isLoggedIn = false;

    public ShopkeeperPro() {
        loginOrSetup();
    }

    void loginOrSetup() {
        File loginFile = new File("login.txt");
        if (!loginFile.exists()) {
            try {
                String newUser = JOptionPane.showInputDialog("नया यूज़रनेम सेट करें:");
                String newPass = JOptionPane.showInputDialog("नया पासवर्ड सेट करें:");

                FileWriter fw = new FileWriter("login.txt");
                fw.write(newUser + "\n" + newPass);
                fw.close();

                JOptionPane.showMessageDialog(this, "सेटअप सफल! अब लॉगिन करें।");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "सेटअप विफल!");
                System.exit(0);
            }
        }

        // Now login
        try {
            BufferedReader br = new BufferedReader(new FileReader("login.txt"));
            String correctUser = br.readLine();
            String correctPass = br.readLine();
            br.close();

            String user = JOptionPane.showInputDialog("यूज़रनेम:");
            String pass = JOptionPane.showInputDialog("पासवर्ड:");

            if (user.equals(correctUser) && pass.equals(correctPass)) {
                isLoggedIn = true;
                setupGUI();
            } else {
                JOptionPane.showMessageDialog(this, "❌ गलत यूज़रनेम या पासवर्ड!");
                System.exit(0);
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "⚠️ लॉगिन फ़ाइल पढ़ने में समस्या!");
            System.exit(0);
        }
    }

    void setupGUI() {
        setTitle("🛍️ प्रोफेशनल दुकानदार प्रणाली");
        setSize(800, 550);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel heading = new JLabel("🧾 दुकान प्रबंधन प्रणाली", JLabel.CENTER);
        heading.setFont(new Font("Serif", Font.BOLD, 26));
        heading.setForeground(Color.BLUE);
        add(heading, BorderLayout.NORTH);

        output = new JTextArea();
        output.setFont(new Font("SansSerif", Font.PLAIN, 16));
        output.setEditable(false);
        JScrollPane scroll = new JScrollPane(output);
        add(scroll, BorderLayout.CENTER);

        JPanel panel = new JPanel(new GridLayout(2, 3));
        btnBuy = new JButton("📦 माल ख़रीदें");
        btnSell = new JButton("💸 माल बेचें");
        btnKhata = new JButton("📖 खाता जोड़ें");
        btnShowSales = new JButton("📋 बिक्री रिपोर्ट");
        btnViewStock = new JButton("🗃️ स्टॉक देखें");
        btnLogout = new JButton("🚪 लॉगआउट");

        panel.add(btnBuy);
        panel.add(btnSell);
        panel.add(btnKhata);
        panel.add(btnShowSales);
        panel.add(btnViewStock);
        panel.add(btnLogout);
        add(panel, BorderLayout.SOUTH);

        btnBuy.addActionListener(this);
        btnSell.addActionListener(this);
        btnKhata.addActionListener(this);
        btnShowSales.addActionListener(this);
        btnViewStock.addActionListener(this);
        btnLogout.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (!isLoggedIn) {
            JOptionPane.showMessageDialog(this, "कृपया पहले लॉगिन करें!");
            return;
        }

        if (e.getSource() == btnBuy) {
            String item = JOptionPane.showInputDialog("📝 वस्तु का नाम दर्ज करें:");
            int qty = Integer.parseInt(JOptionPane.showInputDialog("🔢 खरीदी गई मात्रा:"));
            double price = Double.parseDouble(JOptionPane.showInputDialog("💰 प्रति यूनिट मूल्य:"));

            int currentQty = inventory.getOrDefault(item, 0);
            inventory.put(item, currentQty + qty);

            double total = qty * price;
            String record = "📥 [खरीद] वस्तु: " + item + " | मात्रा: " + qty + " | कुल लागत: ₹" + total;
            output.append(record + "\n");
            saveToFile("purchases.txt", record);

        } else if (e.getSource() == btnSell) {
            String item = JOptionPane.showInputDialog("📝 बेची गई वस्तु का नाम:");
            int qty = Integer.parseInt(JOptionPane.showInputDialog("🔢 बेची गई मात्रा:"));
            double price = Double.parseDouble(JOptionPane.showInputDialog("💵 प्रति यूनिट बिक्री मूल्य:"));

            int stock = inventory.getOrDefault(item, 0);
            if (qty > stock) {
                JOptionPane.showMessageDialog(this, "❌ स्टॉक में पर्याप्त " + item + " नहीं है!");
                return;
            }

            inventory.put(item, stock - qty);

            double total = qty * price;
            totalSales += total;
            String record = "📤 [बिक्री] वस्तु: " + item + " | मात्रा: " + qty + " | कुल राशि: ₹" + total;
            output.append(record + "\n");
            salesRecords.add(record);
            saveToFile("sales.txt", record);

        } else if (e.getSource() == btnKhata) {
            String name = JOptionPane.showInputDialog("👤 ग्राहक/उधारकर्ता का नाम:");
            String desc = JOptionPane.showInputDialog("✏️ विवरण व राशि:");

            String record = "📒 [खाता] " + name + " → " + desc;
            khataBook.add(record);
            output.append(record + "\n");
            saveToFile("khata.txt", record);

        } else if (e.getSource() == btnShowSales) {
            output.append("\n📊 🔻 🔻 🔻 🔻 🔻 🔻\n");
            output.append("📋 आज की बिक्री रिपोर्ट:\n");
            for (String s : salesRecords) {
                output.append("  ✅ " + s + "\n");
            }
            output.append("💰 कुल बिक्री राशि: ₹" + totalSales + "\n");
            output.append("🔺 🔺 🔺 🔺 🔺 🔺\n\n");

        } else if (e.getSource() == btnViewStock) {
            output.append("\n📦 वर्तमान स्टॉक स्थिति:\n");
            for (String key : inventory.keySet()) {
                output.append("  🔸 " + key + ": " + inventory.get(key) + " मात्रा\n");
            }
            output.append("━━━━━━━━━━━━━━━━━━━━━━\n\n");

        } else if (e.getSource() == btnLogout) {
            int confirm = JOptionPane.showConfirmDialog(this, "क्या आप लॉगआउट करना चाहते हैं?");
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
    }

    void saveToFile(String filename, String data) {
        try {
            FileWriter fw = new FileWriter(filename, true);
            fw.write(data + "\n");
            fw.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "⚠️ फ़ाइल सहेजने में समस्या!");
        }
    }

    public static void main(String[] args) {
        new ShopkeeperPro();
    }
}
