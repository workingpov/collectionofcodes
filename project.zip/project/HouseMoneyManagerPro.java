// Paste this in HouseMoneyManagerPro.java file

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class HouseMoneyManagerPro extends JFrame {
    private int totalIncome = 0;
    private int totalExpense = 0;
    private final java.util.List<Expense> expenses = new ArrayList<>();
    private final java.util.List<BorrowLend> records = new ArrayList<>();

    public HouseMoneyManagerPro() {
        setTitle("घर और दुकान पैसे प्रबंधन प्रणाली");
        setSize(600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(10, 2));

        JButton incomeBtn = new JButton("1. Add Income");
        JButton expenseBtn = new JButton("2. Add Expense");
        JButton calcBtn = new JButton("3. Calculator");
        JButton finCalcBtn = new JButton("4. Financial Calculator");
        JButton analysisBtn = new JButton("5. Expense Analysis");
        JButton searchBtn = new JButton("6. Search Expense");
        JButton corruptionBtn = new JButton("7. Corruption Check");
        JButton recordBtn = new JButton("8. Borrow/Lend Record");
        JButton interestBtn = new JButton("9. Interest Calculator");
        JButton shopBtn = new JButton("10. Shop Register");
        JButton profitLossBtn = new JButton("11. Profit/Loss");
        JButton summaryBtn = new JButton("12. Total Summary");

        incomeBtn.addActionListener(e -> addIncome());
        expenseBtn.addActionListener(e -> addExpense());
        calcBtn.addActionListener(e -> basicCalculator());
        finCalcBtn.addActionListener(e -> financialCalculator());
        analysisBtn.addActionListener(e -> showAnalysis());
        searchBtn.addActionListener(e -> searchExpense());
        corruptionBtn.addActionListener(e -> corruptionCheck());
        recordBtn.addActionListener(e -> addBorrowLendRecord());
        interestBtn.addActionListener(e -> interestCalculator());
        shopBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "दुकान रजिस्टर कार्य निर्माणाधीन है।"));
        profitLossBtn.addActionListener(e -> showProfitLoss());
        summaryBtn.addActionListener(e -> showSummary());

        add(incomeBtn); add(expenseBtn); add(calcBtn); add(finCalcBtn);
        add(analysisBtn); add(searchBtn); add(corruptionBtn); add(recordBtn);
        add(interestBtn); add(shopBtn); add(profitLossBtn); add(summaryBtn);
    }

    private void addIncome() {
        try {
            int amt = Integer.parseInt(JOptionPane.showInputDialog("कृपया आय दर्ज करें (₹):"));
            totalIncome += amt;
            JOptionPane.showMessageDialog(this, "आय दर्ज हुई। कुल आय: ₹" + totalIncome);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "अमान्य इनपुट!");
        }
    }

    private void addExpense() {
        try {
            String place = JOptionPane.showInputDialog("खर्च कहाँ हुआ?");
            int amt = Integer.parseInt(JOptionPane.showInputDialog("राशि दर्ज करें:"));
            totalExpense += amt;
            expenses.add(new Expense(place, amt));
            JOptionPane.showMessageDialog(this, "खर्च दर्ज: ₹" + amt + " | स्थान: " + place);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "गलत इनपुट!");
        }
    }

    private void basicCalculator() {
        String[] options = { "+", "-", "*", "/" };
        String op = (String) JOptionPane.showInputDialog(this, "ऑपरेशन चुनें", "कैलकुलेटर", JOptionPane.PLAIN_MESSAGE, null, options, "+");
        int a = Integer.parseInt(JOptionPane.showInputDialog("पहली संख्या:"));
        int b = Integer.parseInt(JOptionPane.showInputDialog("दूसरी संख्या:"));
        int result = switch (op) {
            case "+" -> a + b;
            case "-" -> a - b;
            case "*" -> a * b;
            case "/" -> b != 0 ? a / b : 0;
            default -> 0;
        };
        JOptionPane.showMessageDialog(this, "परिणाम: " + result);
    }

    private void financialCalculator() {
        String place = JOptionPane.showInputDialog("खर्च कहाँ किया?");
        int amt = Integer.parseInt(JOptionPane.showInputDialog("राशि (₹):"));
        int remaining = totalIncome - totalExpense - amt;
        JOptionPane.showMessageDialog(this, "स्थान: " + place + "\nखर्च: ₹" + amt + "\nशेष: ₹" + remaining);
    }

    private void showAnalysis() {
        StringBuilder result = new StringBuilder("💡 खर्च विश्लेषण:\n");
        for (Expense e : expenses) {
            double percent = ((double)e.amount / totalIncome) * 100;
            result.append("🧾 ").append(e.place).append(": ₹").append(e.amount)
                  .append(" (").append(String.format("%.2f", percent)).append("%)\n");
        }
        JOptionPane.showMessageDialog(this, result.toString());
    }

    private void searchExpense() {
        String key = JOptionPane.showInputDialog("स्थान या राशि दर्ज करें:");
        StringBuilder result = new StringBuilder();
        for (Expense e : expenses) {
            if (e.place.equalsIgnoreCase(key) || Integer.toString(e.amount).equals(key)) {
                result.append("🔍 मिला: ").append(e.place).append(" ₹").append(e.amount).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, result.length() > 0 ? result.toString() : "कोई मेल नहीं मिला।");
    }

    private void corruptionCheck() {
        if (totalExpense > totalIncome)
            JOptionPane.showMessageDialog(this, "⚠️ खर्च आय से ज़्यादा है! भ्रष्टाचार?");
        else
            JOptionPane.showMessageDialog(this, "✅ सब ठीक है।");
    }

    private void addBorrowLendRecord() {
        String name = JOptionPane.showInputDialog("नाम:");
        int amt = Integer.parseInt(JOptionPane.showInputDialog("राशि (₹):"));
        double rate = Double.parseDouble(JOptionPane.showInputDialog("ब्याज दर (%):"));
        int months = Integer.parseInt(JOptionPane.showInputDialog("समय (महीने):"));
        double total = amt + (amt * rate * months) / 100.0;
        records.add(new BorrowLend(name, amt, rate, months, total));
        JOptionPane.showMessageDialog(this, "कुल देय: ₹" + String.format("%.2f", total));
    }

    private void interestCalculator() {
        int p = Integer.parseInt(JOptionPane.showInputDialog("मूलधन (₹):"));
        double r = Double.parseDouble(JOptionPane.showInputDialog("ब्याज दर (%):"));
        int t = Integer.parseInt(JOptionPane.showInputDialog("समय (वर्ष):"));
        double interest = (p * r * t) / 100;
        JOptionPane.showMessageDialog(this, "ब्याज: ₹" + interest + "\nकुल: ₹" + (p + interest));
    }

    private void showProfitLoss() {
        int profit = totalIncome - totalExpense;
        String msg = profit >= 0 ? "लाभ: ₹" + profit : "हानि: ₹" + (-profit);
        JOptionPane.showMessageDialog(this, msg);
    }

    private void showSummary() {
        StringBuilder result = new StringBuilder("📊 कुल सारांश:\n");
        result.append("➡️ कुल आय: ₹").append(totalIncome).append("\n");
        result.append("➡️ कुल खर्च: ₹").append(totalExpense).append("\n");
        result.append("➡️ शेष: ₹").append(totalIncome - totalExpense).append("\n");
        result.append("➡️ ऋण/उधार:\n");
        for (BorrowLend b : records) {
            result.append("🔸 ").append(b.name).append(": ₹").append(b.amount)
                  .append(" ब्याज: ").append(b.rate).append("% कुल: ₹").append(b.total).append("\n");
        }
        JOptionPane.showMessageDialog(this, result.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HouseMoneyManagerPro().setVisible(true));
    }
}

class Expense {
    String place;
    int amount;
    Expense(String place, int amount) {
        this.place = place;
        this.amount = amount;
    }
}

class BorrowLend {
    String name;
    int amount;
    double rate;
    int months;
    double total;
    BorrowLend(String name, int amount, double rate, int months, double total) {
        this.name = name;
        this.amount = amount;
        this.rate = rate;
        this.months = months;
        this.total = total;
    }
}
