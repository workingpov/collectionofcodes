import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class ShopkeeperManager {
    private static HashMap<String, Item> inventory = new HashMap<>();
    private static HashMap<String, Customer> khataBook = new HashMap<>();
    private static ArrayList<Transaction> transactions = new ArrayList<>();
    private static ArrayList<Expense> expenses = new ArrayList<>();
    private static ArrayList<Staff> staffMembers = new ArrayList<>();
    private static ArrayList<Purchase> purchases = new ArrayList<>();
    private static double totalIncome = 0;
    private static double totalExpense = 0;
    private static boolean isFirstTime = true;
    private static String username = "admin";
    private static String password = "password123";

    public static void main(String[] args) {
        if (isFirstTime) {
            authenticateUser();
        }
        createMainMenu();
    }

    private static void authenticateUser() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        JLabel userLabel = new JLabel("उपयोगकर्ता नाम:");
        JTextField userText = new JTextField();
        JLabel passLabel = new JLabel("पासवर्ड:");
        JPasswordField passText = new JPasswordField();
        panel.add(userLabel);
        panel.add(userText);
        panel.add(passLabel);
        panel.add(passText);

        int result = JOptionPane.showConfirmDialog(null, panel, "लॉगिन", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            if (!userText.getText().equals(username) || !new String(passText.getPassword()).equals(password)) {
                JOptionPane.showMessageDialog(null, "गलत उपयोगकर्ता नाम या पासवर्ड!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            } else {
                isFirstTime = false;
            }
        } else {
            System.exit(0);
        }
    }

    private static void createMainMenu() {
        JFrame frame = new JFrame("दुकान प्रबंधन प्रणाली");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 2, 10, 10));

        JButton inventoryBtn = new JButton("सामान प्रबंधन");
        JButton billingBtn = new JButton("बिलिंग प्रणाली");
        JButton khataBtn = new JButton("खाता बही");
        JButton incomeExpenseBtn = new JButton("आय/व्यय");
        JButton staffBtn = new JButton("कर्मचारी प्रबंधन");
        JButton purchaseBtn = new JButton("खरीद प्रबंधन");
        JButton searchBtn = new JButton("खोज");
        JButton analysisBtn = new JButton("विश्लेषण");

        inventoryBtn.addActionListener(e -> openInventoryManagement());
        billingBtn.addActionListener(e -> openBillingSystem());
        khataBtn.addActionListener(e -> openKhataBook());
        incomeExpenseBtn.addActionListener(e -> openIncomeExpense());
        staffBtn.addActionListener(e -> openStaffManagement());
        purchaseBtn.addActionListener(e -> openPurchaseManagement());
        searchBtn.addActionListener(e -> openSearchFunction());
        analysisBtn.addActionListener(e -> openAnalysis());

        frame.add(inventoryBtn);
        frame.add(billingBtn);
        frame.add(khataBtn);
        frame.add(incomeExpenseBtn);
        frame.add(staffBtn);
        frame.add(purchaseBtn);
        frame.add(searchBtn);
        frame.add(analysisBtn);

        frame.setVisible(true);
    }

    private static void openInventoryManagement() {
        JFrame frame = new JFrame("सामान प्रबंधन");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(4, 1));

        JButton addItemBtn = new JButton("नया सामान जोड़ें");
        JButton viewItemsBtn = new JButton("सामान की सूची देखें");
        JButton updateItemBtn = new JButton("सामान अद्यतन करें");
        JButton backBtn = new JButton("वापस");

        addItemBtn.addActionListener(e -> addNewItem());
        viewItemsBtn.addActionListener(e -> viewAllItems());
        updateItemBtn.addActionListener(e -> updateItem());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(addItemBtn);
        frame.add(viewItemsBtn);
        frame.add(updateItemBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void addNewItem() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JLabel nameLabel = new JLabel("सामान का नाम:");
        JTextField nameField = new JTextField();
        JLabel priceLabel = new JLabel("मूल्य:");
        JTextField priceField = new JTextField();
        JLabel quantityLabel = new JLabel("मात्रा:");
        JTextField quantityField = new JTextField();

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(priceLabel);
        panel.add(priceField);
        panel.add(quantityLabel);
        panel.add(quantityField);

        int result = JOptionPane.showConfirmDialog(null, panel, "नया सामान जोड़ें", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                int quantity = Integer.parseInt(quantityField.getText());

                if (inventory.containsKey(name)) {
                    JOptionPane.showMessageDialog(null, "यह सामान पहले से मौजूद है!", "चेतावनी", JOptionPane.WARNING_MESSAGE);
                } else {
                    inventory.put(name, new Item(name, price, quantity));
                    JOptionPane.showMessageDialog(null, "सामान सफलतापूर्वक जोड़ा गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "अमान्य संख्या प्रारूप!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewAllItems() {
        if (inventory.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई सामान उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("सामान सूची:\n\n");
        sb.append(String.format("%-20s %-10s %-10s%n", "नाम", "मूल्य", "मात्रा"));
        sb.append("--------------------------------\n");

        for (Item item : inventory.values()) {
            sb.append(String.format("%-20s %-10.2f %-10d%n", item.getName(), item.getPrice(), item.getQuantity()));
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "सामान सूची", JOptionPane.PLAIN_MESSAGE);
    }

    private static void updateItem() {
        String[] items = inventory.keySet().toArray(new String[0]);
        if (items.length == 0) {
            JOptionPane.showMessageDialog(null, "कोई सामान उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String selectedItem = (String) JOptionPane.showInputDialog(null, "सामान चुनें:", "सामान अद्यतन", 
                JOptionPane.PLAIN_MESSAGE, null, items, items[0]);

        if (selectedItem != null) {
            Item item = inventory.get(selectedItem);
            JPanel panel = new JPanel(new GridLayout(3, 2));
            JLabel priceLabel = new JLabel("नया मूल्य:");
            JTextField priceField = new JTextField(String.valueOf(item.getPrice()));
            JLabel quantityLabel = new JLabel("नई मात्रा:");
            JTextField quantityField = new JTextField(String.valueOf(item.getQuantity()));

            panel.add(priceLabel);
            panel.add(priceField);
            panel.add(quantityLabel);
            panel.add(quantityField);

            int result = JOptionPane.showConfirmDialog(null, panel, "सामान अद्यतन", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                try {
                    double newPrice = Double.parseDouble(priceField.getText());
                    int newQuantity = Integer.parseInt(quantityField.getText());
                    item.setPrice(newPrice);
                    item.setQuantity(newQuantity);
                    JOptionPane.showMessageDialog(null, "सामान सफलतापूर्वक अद्यतन किया गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "अमान्य संख्या प्रारूप!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private static void openBillingSystem() {
        JFrame frame = new JFrame("बिलिंग प्रणाली");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(3, 1));

        JButton newBillBtn = new JButton("नया बिल बनाएं");
        JButton viewBillsBtn = new JButton("पिछले बिल देखें");
        JButton backBtn = new JButton("वापस");

        newBillBtn.addActionListener(e -> createNewBill());
        viewBillsBtn.addActionListener(e -> viewPreviousBills());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(newBillBtn);
        frame.add(viewBillsBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void createNewBill() {
        ArrayList<BillItem> billItems = new ArrayList<>();
        double totalAmount = 0;
        boolean continueAdding = true;

        while (continueAdding) {
            String[] items = inventory.keySet().toArray(new String[0]);
            if (items.length == 0) {
                JOptionPane.showMessageDialog(null, "कोई सामान उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String selectedItem = (String) JOptionPane.showInputDialog(null, "सामान चुनें:", "बिल आइटम जोड़ें", 
                    JOptionPane.PLAIN_MESSAGE, null, items, items[0]);

            if (selectedItem == null) {
                continueAdding = false;
                continue;
            }

            Item item = inventory.get(selectedItem);
            String quantityStr = JOptionPane.showInputDialog(null, "मात्रा दर्ज करें (उपलब्ध: " + item.getQuantity() + "):");
            if (quantityStr == null) {
                continue;
            }

            try {
                int quantity = Integer.parseInt(quantityStr);
                if (quantity <= 0) {
                    JOptionPane.showMessageDialog(null, "मात्रा शून्य से अधिक होनी चाहिए!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
                    continue;
                }

                if (quantity > item.getQuantity()) {
                    JOptionPane.showMessageDialog(null, "पर्याप्त स्टॉक उपलब्ध नहीं है!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
                    continue;
                }

                double itemTotal = item.getPrice() * quantity;
                billItems.add(new BillItem(item.getName(), item.getPrice(), quantity, itemTotal));
                totalAmount += itemTotal;
                item.setQuantity(item.getQuantity() - quantity);

                int choice = JOptionPane.showConfirmDialog(null, "क्या आप और आइटम जोड़ना चाहते हैं?", "जारी रखें", JOptionPane.YES_NO_OPTION);
                if (choice != JOptionPane.YES_OPTION) {
                    continueAdding = false;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "अमान्य मात्रा!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
            }
        }

        if (!billItems.isEmpty()) {
            StringBuilder bill = new StringBuilder();
            bill.append("बिल विवरण:\n\n");
            bill.append(String.format("%-20s %-10s %-10s %-10s%n", "सामान", "मूल्य", "मात्रा", "कुल"));
            bill.append("--------------------------------------------\n");

            for (BillItem item : billItems) {
                bill.append(String.format("%-20s %-10.2f %-10d %-10.2f%n", 
                        item.getName(), item.getPrice(), item.getQuantity(), item.getTotal()));
            }

            bill.append("\nकुल राशि: ").append(String.format("%.2f", totalAmount));
            transactions.add(new Transaction(new Date(), billItems, totalAmount));
            totalIncome += totalAmount;

            JTextArea textArea = new JTextArea(bill.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));
            JOptionPane.showMessageDialog(null, scrollPane, "बिल", JOptionPane.PLAIN_MESSAGE);
        }
    }

    private static void viewPreviousBills() {
        if (transactions.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई बिल उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        sb.append("पिछले बिल:\n\n");

        for (int i = 0; i < transactions.size(); i++) {
            Transaction t = transactions.get(i);
            sb.append("बिल #").append(i + 1).append(" - ").append(sdf.format(t.getDate())).append("\n");
            sb.append("कुल राशि: ").append(String.format("%.2f", t.getTotalAmount())).append("\n\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "पिछले बिल", JOptionPane.PLAIN_MESSAGE);
    }

    private static void openKhataBook() {
        JFrame frame = new JFrame("खाता बही");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(4, 1));

        JButton addCustomerBtn = new JButton("नया ग्राहक जोड़ें");
        JButton viewCustomersBtn = new JButton("ग्राहक देखें");
        JButton updateKhataBtn = new JButton("खाता अद्यतन करें");
        JButton backBtn = new JButton("वापस");

        addCustomerBtn.addActionListener(e -> addNewCustomer());
        viewCustomersBtn.addActionListener(e -> viewAllCustomers());
        updateKhataBtn.addActionListener(e -> updateCustomerKhata());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(addCustomerBtn);
        frame.add(viewCustomersBtn);
        frame.add(updateKhataBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void addNewCustomer() {
        JPanel panel = new JPanel(new GridLayout(2, 2));
        JLabel nameLabel = new JLabel("ग्राहक का नाम:");
        JTextField nameField = new JTextField();
        JLabel amountLabel = new JLabel("राशि (उधार):");
        JTextField amountField = new JTextField("0");

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(amountLabel);
        panel.add(amountField);

        int result = JOptionPane.showConfirmDialog(null, panel, "नया ग्राहक", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                double amount = Double.parseDouble(amountField.getText());

                if (khataBook.containsKey(name)) {
                    JOptionPane.showMessageDialog(null, "यह ग्राहक पहले से मौजूद है!", "चेतावनी", JOptionPane.WARNING_MESSAGE);
                } else {
                    khataBook.put(name, new Customer(name, amount));
                    JOptionPane.showMessageDialog(null, "ग्राहक सफलतापूर्वक जोड़ा गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "अमान्य राशि!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewAllCustomers() {
        if (khataBook.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई ग्राहक उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("ग्राहक सूची:\n\n");
        sb.append(String.format("%-20s %-15s%n", "नाम", "उधार राशि"));
        sb.append("--------------------------------\n");

        for (Customer customer : khataBook.values()) {
            sb.append(String.format("%-20s %-15.2f%n", customer.getName(), customer.getAmount()));
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "ग्राहक सूची", JOptionPane.PLAIN_MESSAGE);
    }

    private static void updateCustomerKhata() {
        String[] customers = khataBook.keySet().toArray(new String[0]);
        if (customers.length == 0) {
            JOptionPane.showMessageDialog(null, "कोई ग्राहक उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String selectedCustomer = (String) JOptionPane.showInputDialog(null, "ग्राहक चुनें:", "खाता अद्यतन", 
                JOptionPane.PLAIN_MESSAGE, null, customers, customers[0]);

        if (selectedCustomer != null) {
            Customer customer = khataBook.get(selectedCustomer);
            JPanel panel = new JPanel(new GridLayout(2, 2));
            JLabel amountLabel = new JLabel("नई राशि:");
            JTextField amountField = new JTextField(String.valueOf(customer.getAmount()));
            JLabel actionLabel = new JLabel("कार्रवाई:");
            JComboBox<String> actionCombo = new JComboBox<>(new String[]{"जोड़ें", "घटाएं"});

            panel.add(amountLabel);
            panel.add(amountField);
            panel.add(actionLabel);
            panel.add(actionCombo);

            int result = JOptionPane.showConfirmDialog(null, panel, "खाता अद्यतन", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                try {
                    double amount = Double.parseDouble(amountField.getText());
                    String action = (String) actionCombo.getSelectedItem();

                    if (action.equals("जोड़ें")) {
                        customer.setAmount(customer.getAmount() + amount);
                    } else {
                        customer.setAmount(customer.getAmount() - amount);
                    }

                    JOptionPane.showMessageDialog(null, "खाता सफलतापूर्वक अद्यतन किया गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "अमान्य राशि!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private static void openIncomeExpense() {
        JFrame frame = new JFrame("आय/व्यय");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(3, 1));

        JButton addIncomeBtn = new JButton("आय दर्ज करें");
        JButton addExpenseBtn = new JButton("व्यय दर्ज करें");
        JButton backBtn = new JButton("वापस");

        addIncomeBtn.addActionListener(e -> addIncome());
        addExpenseBtn.addActionListener(e -> addExpense());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(addIncomeBtn);
        frame.add(addExpenseBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void addIncome() {
        String description = JOptionPane.showInputDialog(null, "आय का विवरण दर्ज करें:");
        if (description == null || description.trim().isEmpty()) {
            return;
        }

        String amountStr = JOptionPane.showInputDialog(null, "राशि दर्ज करें:");
        if (amountStr == null) {
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr);
            expenses.add(new Expense(description, amount, true));
            totalIncome += amount;
            JOptionPane.showMessageDialog(null, "आय सफलतापूर्वक दर्ज की गई!", "सफल", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "अमान्य राशि!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void addExpense() {
        String description = JOptionPane.showInputDialog(null, "व्यय का विवरण दर्ज करें:");
        if (description == null || description.trim().isEmpty()) {
            return;
        }

        String amountStr = JOptionPane.showInputDialog(null, "राशि दर्ज करें:");
        if (amountStr == null) {
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr);
            expenses.add(new Expense(description, amount, false));
            totalExpense += amount;
            JOptionPane.showMessageDialog(null, "व्यय सफलतापूर्वक दर्ज किया गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "अमान्य राशि!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void openStaffManagement() {
        JFrame frame = new JFrame("कर्मचारी प्रबंधन");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(4, 1));

        JButton addStaffBtn = new JButton("नया कर्मचारी जोड़ें");
        JButton viewStaffBtn = new JButton("कर्मचारी देखें");
        JButton paySalaryBtn = new JButton("वेतन भुगतान");
        JButton backBtn = new JButton("वापस");

        addStaffBtn.addActionListener(e -> addNewStaff());
        viewStaffBtn.addActionListener(e -> viewAllStaff());
        paySalaryBtn.addActionListener(e -> payStaffSalary());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(addStaffBtn);
        frame.add(viewStaffBtn);
        frame.add(paySalaryBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void addNewStaff() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        JLabel nameLabel = new JLabel("कर्मचारी का नाम:");
        JTextField nameField = new JTextField();
        JLabel salaryLabel = new JLabel("मासिक वेतन:");
        JTextField salaryField = new JTextField();

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(salaryLabel);
        panel.add(salaryField);

        int result = JOptionPane.showConfirmDialog(null, panel, "नया कर्मचारी", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                double salary = Double.parseDouble(salaryField.getText());

                staffMembers.add(new Staff(name, salary));
                JOptionPane.showMessageDialog(null, "कर्मचारी सफलतापूर्वक जोड़ा गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "अमान्य वेतन!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewAllStaff() {
        if (staffMembers.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई कर्मचारी उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("कर्मचारी सूची:\n\n");
        sb.append(String.format("%-20s %-15s%n", "नाम", "वेतन"));
        sb.append("--------------------------------\n");

        for (Staff staff : staffMembers) {
            sb.append(String.format("%-20s %-15.2f%n", staff.getName(), staff.getSalary()));
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "कर्मचारी सूची", JOptionPane.PLAIN_MESSAGE);
    }

    private static void payStaffSalary() {
        if (staffMembers.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई कर्मचारी उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] staffNames = new String[staffMembers.size()];
        for (int i = 0; i < staffMembers.size(); i++) {
            staffNames[i] = staffMembers.get(i).getName();
        }

        String selectedStaff = (String) JOptionPane.showInputDialog(null, "कर्मचारी चुनें:", "वेतन भुगतान", 
                JOptionPane.PLAIN_MESSAGE, null, staffNames, staffNames[0]);

        if (selectedStaff != null) {
            for (Staff staff : staffMembers) {
                if (staff.getName().equals(selectedStaff)) {
                    String amountStr = JOptionPane.showInputDialog(null, "भुगतान की गई राशि दर्ज करें:", String.valueOf(staff.getSalary()));
                    if (amountStr != null) {
                        try {
                            double amount = Double.parseDouble(amountStr);
                            expenses.add(new Expense(staff.getName() + " का वेतन", amount, false));
                            totalExpense += amount;
                            JOptionPane.showMessageDialog(null, "वेतन भुगतान सफलतापूर्वक दर्ज किया गया!", "सफल", JOptionPane.INFORMATION_MESSAGE);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "अमान्य राशि!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    break;
                }
            }
        }
    }

    private static void openPurchaseManagement() {
        JFrame frame = new JFrame("खरीद प्रबंधन");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(3, 1));

        JButton newPurchaseBtn = new JButton("नई खरीद दर्ज करें");
        JButton viewPurchasesBtn = new JButton("खरीद इतिहास देखें");
        JButton backBtn = new JButton("वापस");

        newPurchaseBtn.addActionListener(e -> addNewPurchase());
        viewPurchasesBtn.addActionListener(e -> viewAllPurchases());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(newPurchaseBtn);
        frame.add(viewPurchasesBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void addNewPurchase() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JLabel itemLabel = new JLabel("सामान का नाम:");
        JTextField itemField = new JTextField();
        JLabel priceLabel = new JLabel("प्रति इकाई मूल्य:");
        JTextField priceField = new JTextField();
        JLabel quantityLabel = new JLabel("मात्रा:");
        JTextField quantityField = new JTextField();
        JLabel supplierLabel = new JLabel("आपूर्तिकर्ता:");
        JTextField supplierField = new JTextField();

        panel.add(itemLabel);
        panel.add(itemField);
        panel.add(priceLabel);
        panel.add(priceField);
        panel.add(quantityLabel);
        panel.add(quantityField);
        panel.add(supplierLabel);
        panel.add(supplierField);

        int result = JOptionPane.showConfirmDialog(null, panel, "नई खरीद", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String itemName = itemField.getText();
                double price = Double.parseDouble(priceField.getText());
                int quantity = Integer.parseInt(quantityField.getText());
                String supplier = supplierField.getText();
                double totalCost = price * quantity;

                purchases.add(new Purchase(itemName, price, quantity, supplier, new Date(), totalCost));

                // Add to inventory or update existing item
                if (inventory.containsKey(itemName)) {
                    Item item = inventory.get(itemName);
                    item.setQuantity(item.getQuantity() + quantity);
                    // Update price if different
                    if (item.getPrice() != price) {
                        item.setPrice(price);
                    }
                } else {
                    inventory.put(itemName, new Item(itemName, price, quantity));
                }

                expenses.add(new Expense(itemName + " की खरीद", totalCost, false));
                totalExpense += totalCost;

                JOptionPane.showMessageDialog(null, "खरीद सफलतापूर्वक दर्ज की गई!", "सफल", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "अमान्य संख्या प्रारूप!", "त्रुटि", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewAllPurchases() {
        if (purchases.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई खरीद उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder sb = new StringBuilder();
        sb.append("खरीद इतिहास:\n\n");
        sb.append(String.format("%-15s %-15s %-10s %-10s %-15s %-10s%n", 
                "तारीख", "सामान", "मूल्य", "मात्रा", "आपूर्तिकर्ता", "कुल"));
        sb.append("----------------------------------------------------------------\n");

        for (Purchase purchase : purchases) {
            sb.append(String.format("%-15s %-15s %-10.2f %-10d %-15s %-10.2f%n", 
                    sdf.format(purchase.getDate()), purchase.getItemName(), 
                    purchase.getPrice(), purchase.getQuantity(), 
                    purchase.getSupplier(), purchase.getTotalCost()));
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "खरीद इतिहास", JOptionPane.PLAIN_MESSAGE);
    }

    private static void openSearchFunction() {
        JFrame frame = new JFrame("खोज");
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(4, 1));

        JButton searchItemBtn = new JButton("सामान खोजें");
        JButton searchCustomerBtn = new JButton("ग्राहक खोजें");
        JButton searchStaffBtn = new JButton("कर्मचारी खोजें");
        JButton backBtn = new JButton("वापस");

        searchItemBtn.addActionListener(e -> searchItems());
        searchCustomerBtn.addActionListener(e -> searchCustomers());
        searchStaffBtn.addActionListener(e -> searchStaff());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(searchItemBtn);
        frame.add(searchCustomerBtn);
        frame.add(searchStaffBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void searchItems() {
        String searchTerm = JOptionPane.showInputDialog(null, "सामान का नाम दर्ज करें:");
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("खोज परिणाम:\n\n");

        boolean found = false;
        for (Item item : inventory.values()) {
            if (item.getName().toLowerCase().contains(searchTerm.toLowerCase())) {
                sb.append(String.format("%-20s %-10.2f %-10d%n", item.getName(), item.getPrice(), item.getQuantity()));
                found = true;
            }
        }

        if (!found) {
            sb.append("कोई मिलान सामान नहीं मिला!");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        JOptionPane.showMessageDialog(null, scrollPane, "सामान खोज", JOptionPane.PLAIN_MESSAGE);
    }

    private static void searchCustomers() {
        String searchTerm = JOptionPane.showInputDialog(null, "ग्राहक का नाम दर्ज करें:");
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("खोज परिणाम:\n\n");

        boolean found = false;
        for (Customer customer : khataBook.values()) {
            if (customer.getName().toLowerCase().contains(searchTerm.toLowerCase())) {
                sb.append(String.format("%-20s %-15.2f%n", customer.getName(), customer.getAmount()));
                found = true;
            }
        }

        if (!found) {
            sb.append("कोई मिलान ग्राहक नहीं मिला!");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        JOptionPane.showMessageDialog(null, scrollPane, "ग्राहक खोज", JOptionPane.PLAIN_MESSAGE);
    }

    private static void searchStaff() {
        String searchTerm = JOptionPane.showInputDialog(null, "कर्मचारी का नाम दर्ज करें:");
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("खोज परिणाम:\n\n");

        boolean found = false;
        for (Staff staff : staffMembers) {
            if (staff.getName().toLowerCase().contains(searchTerm.toLowerCase())) {
                sb.append(String.format("%-20s %-15.2f%n", staff.getName(), staff.getSalary()));
                found = true;
            }
        }

        if (!found) {
            sb.append("कोई मिलान कर्मचारी नहीं मिला!");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        JOptionPane.showMessageDialog(null, scrollPane, "कर्मचारी खोज", JOptionPane.PLAIN_MESSAGE);
    }

    private static void openAnalysis() {
        JFrame frame = new JFrame("विश्लेषण");
        frame.setSize(500, 400);
        frame.setLayout(new GridLayout(5, 1));

        JButton profitLossBtn = new JButton("लाभ/हानि विवरण");
        JButton topItemsBtn = new JButton("सर्वाधिक बिकने वाले सामान");
        JButton expensesBtn = new JButton("व्यय विवरण");
        JButton summaryBtn = new JButton("सारांश");
        JButton backBtn = new JButton("वापस");

        profitLossBtn.addActionListener(e -> showProfitLoss());
        topItemsBtn.addActionListener(e -> showTopItems());
        expensesBtn.addActionListener(e -> showExpenses());
        summaryBtn.addActionListener(e -> showSummary());
        backBtn.addActionListener(e -> frame.dispose());

        frame.add(profitLossBtn);
        frame.add(topItemsBtn);
        frame.add(expensesBtn);
        frame.add(summaryBtn);
        frame.add(backBtn);

        frame.setVisible(true);
    }

    private static void showProfitLoss() {
        double profit = totalIncome - totalExpense;
        String message = String.format("कुल आय: %.2f\nकुल व्यय: %.2f\nशुद्ध लाभ/हानि: %.2f", 
                totalIncome, totalExpense, profit);
        JOptionPane.showMessageDialog(null, message, "लाभ/हानि विवरण", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void showTopItems() {
        if (transactions.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई बिक्री डेटा उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        HashMap<String, Integer> itemCount = new HashMap<>();
        for (Transaction t : transactions) {
            for (BillItem item : t.getItems()) {
                itemCount.put(item.getName(), itemCount.getOrDefault(item.getName(), 0) + item.getQuantity());
            }
        }

        // Sort items by quantity sold
        ArrayList<Map.Entry<String, Integer>> sortedItems = new ArrayList<>(itemCount.entrySet());
        sortedItems.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        StringBuilder sb = new StringBuilder();
        sb.append("सर्वाधिक बिकने वाले सामान:\n\n");
        sb.append(String.format("%-20s %-10s%n", "सामान", "बिक्री"));
        sb.append("------------------------\n");

        int limit = Math.min(5, sortedItems.size()); // Show top 5 or less
        for (int i = 0; i < limit; i++) {
            Map.Entry<String, Integer> entry = sortedItems.get(i);
            sb.append(String.format("%-20s %-10d%n", entry.getKey(), entry.getValue()));
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(300, 200));
        JOptionPane.showMessageDialog(null, scrollPane, "शीर्ष बिकने वाले सामान", JOptionPane.PLAIN_MESSAGE);
    }

    private static void showExpenses() {
        if (expenses.isEmpty()) {
            JOptionPane.showMessageDialog(null, "कोई व्यय डेटा उपलब्ध नहीं है!", "सूचना", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("व्यय विवरण:\n\n");
        sb.append(String.format("%-30s %-15s %-10s%n", "विवरण", "राशि", "प्रकार"));
        sb.append("--------------------------------------------------\n");

        for (Expense expense : expenses) {
            String type = expense.isIncome() ? "आय" : "व्यय";
            sb.append(String.format("%-30s %-15.2f %-10s%n", 
                    expense.getDescription(), expense.getAmount(), type));
        }

        sb.append("\nकुल व्यय: ").append(String.format("%.2f", totalExpense));

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "व्यय विवरण", JOptionPane.PLAIN_MESSAGE);
    }

    private static void showSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("सारांश रिपोर्ट:\n\n");
        sb.append(String.format("%-30s %-15s%n", "कुल सामान:", inventory.size()));
        sb.append(String.format("%-30s %-15s%n", "कुल ग्राहक:", khataBook.size()));
        sb.append(String.format("%-30s %-15s%n", "कुल कर्मचारी:", staffMembers.size()));
        sb.append(String.format("%-30s %-15.2f%n", "कुल आय:", totalIncome));
        sb.append(String.format("%-30s %-15.2f%n", "कुल व्यय:", totalExpense));
        sb.append(String.format("%-30s %-15.2f%n", "शुद्ध लाभ/हानि:", (totalIncome - totalExpense)));
        sb.append(String.format("%-30s %-15s%n", "कुल बिल:", transactions.size()));
        sb.append(String.format("%-30s %-15s%n", "कुल खरीद:", purchases.size()));

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "सारांश रिपोर्ट", JOptionPane.PLAIN_MESSAGE);
    }

    // Helper classes
    static class Item {
        private String name;
        private double price;
        private int quantity;

        public Item(String name, double price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }

        public String getName() { return name; }
        public double getPrice() { return price; }
        public int getQuantity() { return quantity; }
        public void setPrice(double price) { this.price = price; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
    }

    static class Customer {
        private String name;
        private double amount;

        public Customer(String name, double amount) {
            this.name = name;
            this.amount = amount;
        }

        public String getName() { return name; }
        public double getAmount() { return amount; }
        public void setAmount(double amount) { this.amount = amount; }
    }

    static class Transaction {
        private Date date;
        private ArrayList<BillItem> items;
        private double totalAmount;

        public Transaction(Date date, ArrayList<BillItem> items, double totalAmount) {
            this.date = date;
            this.items = items;
            this.totalAmount = totalAmount;
        }

        public Date getDate() { return date; }
        public ArrayList<BillItem> getItems() { return items; }
        public double getTotalAmount() { return totalAmount; }
    }

    static class BillItem {
        private String name;
        private double price;
        private int quantity;
        private double total;

        public BillItem(String name, double price, int quantity, double total) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
            this.total = total;
        }

        public String getName() { return name; }
        public double getPrice() { return price; }
        public int getQuantity() { return quantity; }
        public double getTotal() { return total; }
    }

    static class Expense {
        private String description;
        private double amount;
        private boolean isIncome;

        public Expense(String description, double amount, boolean isIncome) {
            this.description = description;
            this.amount = amount;
            this.isIncome = isIncome;
        }

        public String getDescription() { return description; }
        public double getAmount() { return amount; }
        public boolean isIncome() { return isIncome; }
    }

    static class Staff {
        private String name;
        private double salary;

        public Staff(String name, double salary) {
            this.name = name;
            this.salary = salary;
        }

        public String getName() { return name; }
        public double getSalary() { return salary; }
    }

    static class Purchase {
        private String itemName;
        private double price;
        private int quantity;
        private String supplier;
        private Date date;
        private double totalCost;

        public Purchase(String itemName, double price, int quantity, String supplier, Date date, double totalCost) {
            this.itemName = itemName;
            this.price = price;
            this.quantity = quantity;
            this.supplier = supplier;
            this.date = date;
            this.totalCost = totalCost;
        }

        public String getItemName() { return itemName; }
        public double getPrice() { return price; }
        public int getQuantity() { return quantity; }
        public String getSupplier() { return supplier; }
        public Date getDate() { return date; }
        public double getTotalCost() { return totalCost; }
    }
}